function buttonE() {
    document.getElementById("button1").style.backgroundColor = "green";;
    document.getElementById("button1").style.width = "100px";
    document.getElementById("button1").style.height = "100px";
    document.getElementById("button2").style.width = "50px";
    document.getElementById("button2").style.height = "50px";
    document.getElementById("button2").backgroundColor = "grey";

}
function buttonT() {
    document.getElementById("button2").style.backgroundColor = "red";
    document.getElementById("button2").style.width = "100px";
    document.getElementById("button2").style.height = "100px";
    document.getElementById("button1").style.width = "50px";
    document.getElementById("button1").style.height = "50px";
    document.getElementById("button1").backgroundColor = "gray";
}
